const questions = [
  {
    "question": "What Is Your Body Frame?",
    "answer1": "Thin, bony and small framed. hardly gain weight",
    "answer1Total": "1",
    "answer2": "Medium built, can gain or loss weight easily ",
    "answer2Total": "2",
    "answer3": "Large built. gain weight easily but difficult to lose",
    "answer3Total": "3"
  },
  {
    "question": "How You Walk & Talk?",
    "answer1": "Fast walk and talk",
    "answer1Total": "1",
    "answer2": "Moderate and determined walk",
    "answer2Total": "2",
    "answer3": "Slow and steady walk",
    "answer3Total": "3"
  },
  {
    "question":
      "How Is Your Weather Reaction?",
    "answer1": "Enjoy warm climate but feel uncomfortable in cool weather",
    "answer1Total": "1",
    "answer2": "Enjoy cool weather and disklike warm climate",
    "answer2Total": "3",
    "answer3": "Comfortable for most of year but prefer summer and spring. Don not like damp climate",
    "answer3Total": "2"
  },
  {
    "question": "How is Your Sweating?",
    "answer1": "sweat little but not much.have minimal body odour.",
    "answer1Total": "3",
    "answer2": "Sweat a lot. Have medium body odour.",
    "answer2Total": "2",
    "answer3":
      "Sweat moderately but sweat a lot when working hard. have strong body odour",
    "answer3Total": "1"
  },
  {
    "question": "How is Your Appetite?",
    "answer1": "Irrgular sometimes i feel hungry sometimes i don't'.",
    "answer1Total": "1",
    "answer2": "Strong and sharp. always feel hungry.",
    "answer2Total": "2",
    "answer3": "Decent Appetite. have tendecy to eat for comfort and teste.",
    "answer3Total": "3"
  },
  {
    "question":
      "How is your skin?",
    "answer1":
      "Normal to dry, rough, thin and cool. Skin issues like dryness, dullness and wrinkly",
    "answer1Total": "3",
    "answer2": "Normal to oily, soft, reddish, sensitive and warm. Skin issues like inflammation",
    "answer2Total": "2",
    "answer3": "Normal to oily, soft, thick and cool. Skin issues like excessive oily, iching fungal infections.",
    "answer3Total": "1"
  },
  {
    "question": "What is your hair type?",
    "answer1": "Rough, dry and wavy. I get split  ends easily",
    "answer1Total": "1",
    "answer2": "Normal, straight, thin and browny",
    "answer2Total": "2",
    "answer3": "Thick, curly and oily. Hair colour tends to be on darker side.",
    "answer3Total": "3"
  }
  
]
